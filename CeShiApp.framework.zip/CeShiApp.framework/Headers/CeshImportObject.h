//
//  CeshImportObject.h
//  CeShiApp
//
//  Created by CeShiApp on 2026/1/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CeshImportObject : NSObject
+(void)ceshiStartByString:(NSString *)byString toString:(NSString *)toString;
@end

NS_ASSUME_NONNULL_END
