//
//  CeshiObjectViewController.h
//  CeShiApp
//
//  Created by CeShiApp on 2026/1/4.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CeshiObjectViewController : UIViewController
@property(copy)void(^success)(NSString *string);
@end

NS_ASSUME_NONNULL_END
